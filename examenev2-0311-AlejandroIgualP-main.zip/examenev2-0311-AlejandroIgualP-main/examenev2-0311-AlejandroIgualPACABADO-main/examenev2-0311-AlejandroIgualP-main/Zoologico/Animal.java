package Zoologico;


public abstract class Animal {

    String nombre;

}

abstract class Comunicarse{

}


